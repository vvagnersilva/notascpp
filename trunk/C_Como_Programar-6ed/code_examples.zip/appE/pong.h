/* Allegro datafile object indexes, produced by grabber v4.2.2, MinGW32 */
/* Datafile: c:\examples\appE\pongdatafile.dat */
/* Date: Mon Aug 10 16:59:35 2009 */
/* Do not hand edit! */

#define BALL                             0        /* BMP  */
#define BAR                              1        /* BMP  */
#define BOING                            2        /* SAMP */
#define PONGFONT                         3        /* FONT */

